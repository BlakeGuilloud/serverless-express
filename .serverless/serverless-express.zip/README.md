# serverless-express
Using express with the Serverless framework. WAHOO!

Huge thanks to the people that put this together: [Deploy a REST API using Serverless, Express and Node.js](https://serverless.com/blog/serverless-express-rest-api/#converting-an-existing-express-application)

A bunch of awesome tools are mentioned in the article.
